# Abu Dhabi Moving Checklist

Use this checklist to organize the practical details of a residential or office relocation.

## Before booking

- Record the current property type and destination property type.
- Make a room-by-room inventory.
- Identify large, fragile, heavy, or special items.
- Note stairs, elevator access, corridor width, and parking conditions.
- Confirm the intended moving date and any timing restrictions.
- Decide which items need packing support and which will be packed independently.
- Ask building or property management about move-related access procedures.

## One week before the move

- Start packing non-essential belongings.
- Label boxes by room or destination.
- Separate fragile items and mark them clearly.
- Measure oversized furniture against doors, corridors, and lifts.
- Keep important documents and personal valuables separate from general moving boxes.
- Confirm access at both the collection and destination properties.

## The day before

- Finish agreed packing tasks.
- Clear walkways, doors, and loading routes.
- Keep keys, access cards, and building instructions available.
- Group items by room where practical.
- Prepare a simple destination-placement plan for larger furniture.

## On moving day

- Keep one person available to answer access and placement questions.
- Point out fragile, heavy, or unusual items before loading begins.
- Confirm the intended destination for major furniture.
- Check rooms, cupboards, and storage areas before leaving the old property.
- At the destination, direct labelled boxes to the correct rooms.

## After unloading

- Confirm that major items have reached the intended rooms.
- Keep hardware and fittings organized if selected furniture requires reassembly.
- Unpack priority items first.
- Review remaining boxes by room instead of opening everything at once.

## Why this helps

A written checklist reduces last-minute decisions and gives everyone involved a clearer understanding of the property, belongings, access conditions, and moving sequence.

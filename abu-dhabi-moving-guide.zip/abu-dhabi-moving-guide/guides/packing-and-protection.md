# Packing and Furniture Protection Guide

Organized packing helps make loading, transportation, unloading, and final placement easier to manage.

## Group items by room

Pack room by room where practical. Label each box with:

- Room name
- General contents
- Fragile status where relevant
- Destination room if it differs from the current room

Avoid using vague labels such as “miscellaneous” for most boxes.

## Common protective materials

Depending on the item and the agreed moving scope, suitable materials can include:

- Moving boxes
- Bubble wrap
- Furniture blankets
- Padding
- Straps

The exact materials and packing method should match the belongings being moved.

## Furniture preparation

Before moving larger furniture:

- Empty loose contents where appropriate.
- Remove detachable parts when necessary and safe to do so.
- Keep screws and fittings together in labelled bags.
- Measure large items and access routes.
- Identify surfaces that need additional protection.

Dismantling and reassembly may be arranged for selected furniture when required, depending on the moving scope.

## Fragile items

For fragile belongings:

- Avoid overloading boxes.
- Use suitable internal protection.
- Keep fragile items clearly identified.
- Tell the moving team about unusual or especially delicate pieces.

## Essentials

Prepare a separate essentials group for items likely to be needed immediately after arrival. This can reduce unnecessary unpacking on the first day.

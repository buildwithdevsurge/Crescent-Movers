# Preparing Information for a Moving Quote

A useful moving quote depends on accurate information about the actual relocation.

## Property information

Prepare:

- Current property type
- Destination property type
- Approximate amount of furniture and boxes
- Collection and destination areas
- Stairs, elevator, parking, and loading conditions

## Inventory information

Highlight:

- Large furniture
- Fragile items
- Heavy or special items
- Pianos or other items requiring extra planning
- Selected items requiring delivery
- Furniture that may need dismantling or reassembly

## Packing requirements

Explain:

- Whether packing support is required
- Which rooms or item groups need packing
- Whether furniture protection is required
- Any fragile-item preparation needs

## Timing

Provide the preferred moving date and relevant access window. Same-day or urgent moving support should always be confirmed for current availability because it depends on the location, team availability, and moving requirements.

## Why detail matters

Moving costs can depend on property size, inventory, distance, access, packing, materials, special items, and scheduling. Sharing accurate information helps the moving scope reflect the actual job rather than an assumed standard move.

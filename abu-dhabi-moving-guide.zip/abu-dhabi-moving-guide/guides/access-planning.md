# Building Access and Loading Planning

Access conditions can affect how a move is organized. A short access review before moving day can prevent avoidable delays.

## Collection property

Check:

- Distance from the nearest practical parking or loading point to the entrance
- Steps, ramps, narrow doors, or tight corridors
- Elevator availability and usable dimensions
- Any shared-space restrictions
- Building access cards, reception procedures, or security requirements
- Suitable routes for larger furniture

## Destination property

Repeat the same review at the new location. Do not assume the destination has the same access conditions as the collection property.

## Elevators

Where elevators are involved:

- Confirm whether a service elevator is available.
- Ask whether a booking or time slot is required.
- Check whether large furniture can fit safely.
- Confirm any property-management requirements directly with the building.

Requirements vary by property, so building-specific rules should not be assumed.

## Parking and loading

Useful questions include:

- Where can the moving vehicle stop?
- Is the loading area close to the entrance?
- Are there time restrictions?
- Does property management require advance coordination?
- Is the route clear enough for larger items?

## Furniture route check

For sofas, wardrobes, tables, cabinets, pianos, and other bulky items, compare item dimensions with:

- Doorways
- Hallways
- Stairwells
- Lift doors and interiors
- Corners and turning points

A route check is easier before moving day than after a large item has already reached a narrow access point.
